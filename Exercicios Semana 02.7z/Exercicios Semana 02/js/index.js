// Ex 1 e 2

let nome = window.prompt('Insira seu nome!')
document.write(nome);

let email = window.prompt('Insira seu email!')
document.write(email);

//Ex 3

var nota = window.prompt("Digite sua nota 1");
var nota2 = window.prompt("Digite sua nota 2");
var nota3 = window.prompt("Digite sua nota 3");
var notas = (parseFloat(nota) + parseFloat(nota2) + parseFloat(nota3)) / 3;
if (notas < 7) {
  alert("Reprovado");
} else if (notas < 10) {
  alert("Aprovado na média");
} else if (notas == 10) {
  alert("Aprovado com excelência!");
}

document.write(notas);

//Ex 5 Par ou Impar

let informarParImpar = function (num1){
    let resultado;
    if(num1 % 2 == 0){
        resultado = 'Par'
    } else if(num1 %2 == 1){
        resultado = 'Ímpar'
    } else{ resultado = "inválido"}

    return resultado
}
console.log(informarParImpar(0));

//Ex 6 IMC

window.onload = () => {
    let button = document.querySelector("#btn");
  
    button.addEventListener("click", calcularIMC);
};
  
function calcularIMC() {

    let altura = parseInt(document
            .querySelector("#height").value);

    let peso = parseInt(document
            .querySelector("#weight").value);
  
    let resultado = document.querySelector("#result");

    if (altura === "" || isNaN(altura)) 
        result.innerHTML = "Provide a valid Height!";
  
    else if (peso === "" || isNaN(peso)) 
        result.innerHTML = "Provide a valid Weight!";

    else {
        let bmi = (peso / ((altura * altura) 
                            / 10000)).toFixed(2);
  
        if (bmi < 18.6) result.innerHTML =
            `Você está abaixo do peso, procure um médico! <span>${bmi}</span>`;
  
        else if (bmi >= 18.6 && bmi < 24.9) 
            result.innerHTML = 
                `PARABÉNS!! Você está no peso ideal! <span>${bmi}</span>`;
  
        else result.innerHTML =
            `Você está acima do peso, procure um médico! <span>${bmi}</span>`;
    }
}

//Ex 7
var contador = 0,
  resposta,
  quantidadesPessoas = 0;

while (contador < 4) {
  resposta = window.prompt(
    'Qual a sua classificação para a a série "Stranger Things"?'
  ); //captura a responta do usuário
  switch (resposta) { 
    case 'ruim':      
    quantidadesPessoas++;
      break;
    case "bom":
      break;
    case "excelente":
      break;
    default:
      resposta = window.prompt(
        'Responda apenas com bom, ruim e excelente.\n Digite novamente sua avaliação'
      ); 
      if (resposta == "ruim") {
        quantidadesPessoas++;
      }
  }
  contador++;
}
console.log("Quantidade de pessoas que classificou a serie como ruim: ", quantidadesPessoas);

// Ex 8

for (let i = 1; i <= 10; i++) {
    let result = 5 * i;
    console.log(result);
    document.write("<p>5 x ", i ,"=", result, "</p>");
}

